#include "OCRRecognize.h"

using namespace cv;

OCRRecognize::OCRRecognize()
{
	mOCRAPI = new tesseract::TessBaseAPI();
	const char  *languagePath = "./tessdata";
	//const char  *languagePath = "tessdata";
	if (mOCRAPI->Init(languagePath, "kz") != 0) {
		delete mOCRAPI;
		mOCRAPI = 0;
		return;
	}
	mOCRAPI->SetPageSegMode(tesseract::PSM_SINGLE_LINE);
	mOCRAPI->SetVariable("tessedit_char_whitelist", "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ<");
}

OCRRecognize::OCRRecognize(std::string lang, const Mat &srcImg)
	:mSrcImg(srcImg)
{
	//tesseract::OEM_TESSERACT_LSTM_COMBINED
	mOCRAPI = new tesseract::TessBaseAPI();
	const char  *languagePath = "./tessdata";
	if (mOCRAPI->Init(languagePath, lang.c_str(), tesseract::OEM_TESSERACT_LSTM_COMBINED) != 0) {
		delete mOCRAPI;
		mOCRAPI = 0;
		return;
	}
	mOCRAPI->SetPageSegMode(tesseract::PSM_AUTO);
	mOCRAPI->SetVariable("tessedit_char_whitelist", "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ<");
}


OCRRecognize::~OCRRecognize()
{
}

char *OCRRecognize::startRecognize()
{
	if (mOCRAPI == 0)
		return 0;
	
	//mOCRAPI->SetImage(mSrcImg.data, mSrcImg.cols, mSrcImg.rows, mSrcImg.channels(), mSrcImg.step[0]);
	mOCRAPI->SetImage(mSrcImg.data, mSrcImg.cols, mSrcImg.rows, 1, mSrcImg.cols);
	/*int depth = mSrcImg.depth();
	if (depth == CV_8U)
		depth = 8;
	PIX *pix = pixCreateHeader(mSrcImg.size().width, mSrcImg.size().height, depth);
	pix->data = (l_uint32 *)mSrcImg.data;
	mOCRAPI->SetImage(pix);*/
	char *out = mOCRAPI->GetUTF8Text();
	return out;
}

char *OCRRecognize::recognize(const cv::Mat &img)
{
	if (mOCRAPI == 0)
		return 0;
	mOCRAPI->SetImage(img.data, img.cols, img.rows, img.channels(), img.step[0]);
	mOCRAPI->SetSourceResolution(720);
	char *out = mOCRAPI->GetUTF8Text();
	return out;
}

char *OCRRecognize::recognize(const char *filename)
{
	if (mOCRAPI == 0)
		return "";
	Pix *pix = pixRead(filename);
	mOCRAPI->SetImage(pix);
	char *out = mOCRAPI->GetUTF8Text();
	return out;
}
