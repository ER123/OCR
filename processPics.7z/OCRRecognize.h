#pragma once
#include <string>
#include <opencv2/core/core.hpp>
#include <tesseract/baseapi.h>
#include <leptonica/allheaders.h>

class OCRRecognize
{
public:
	OCRRecognize();
	OCRRecognize(std::string lang, const cv::Mat &srcImg);
	~OCRRecognize();
	char *recognize(const char *filename);
	char *startRecognize();
	char *recognize(const cv::Mat &img);
private:
	cv::Mat mSrcImg;
	tesseract::TessBaseAPI *mOCRAPI;
};

